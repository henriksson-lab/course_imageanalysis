// The checks of day 38, one module per unit:  cargo test -p evaluation <unit>::

mod object_eval;
mod agreement;
mod leakage;
mod replicates;
