// Model solution for the coding exercises of "Grey-level morphology: top-hat and gradient".
//
// A flat structuring element (SE) is a list of offsets (dx, dy) from its origin, no
// weights. At the image border only the pixels inside the image count (as in the exercises).

use imgcourse::Image;

/// A digital disc of radius `r`: all offsets with dx² + dy² ≤ r².
pub fn disc(r: usize) -> Vec<(isize, isize)> {
    let r = r as isize;
    let mut se = Vec::new();
    for dy in -r..=r {
        for dx in -r..=r {
            if dx * dx + dy * dy <= r * r {
                se.push((dx, dy));
            }
        }
    }
    se
}

/// A horizontal window of `width` samples centred on the origin (`width` odd), for 1D
/// signals stored as images of height 1.
pub fn window(width: usize) -> Vec<(isize, isize)> {
    let k = (width / 2) as isize;
    (-k..=k).map(|dx| (dx, 0)).collect()
}

/// The values of `img` at x + sign · b for all offsets b of the SE that land inside the image
/// (`sign` 1 for erosion, −1 for dilation).
pub fn values_at(img: &Image<f32>, x: usize, y: usize, se: &[(isize, isize)], sign: isize) -> Vec<f32> {
    let mut v = Vec::with_capacity(se.len());
    for &(dx, dy) in se {
        let (u, w) = (x as isize + sign * dx, y as isize + sign * dy);
        if img.contains(u, w) {
            v.push(img[(u as usize, w as usize)]);
        }
    }
    v
}

/// C1a. Erosion with a flat SE: the minimum of I(x + b) over the SE (a min filter).
pub fn erode(img: &Image<f32>, se: &[(isize, isize)]) -> Image<f32> {
    img.map_xy(|x, y, _| values_at(img, x, y, se, 1).into_iter().fold(f32::INFINITY, f32::min))
}

/// C1b. Dilation with a flat SE: the maximum of I(x − b) over the SE (a max filter).
pub fn dilate(img: &Image<f32>, se: &[(isize, isize)]) -> Image<f32> {
    img.map_xy(|x, y, _| values_at(img, x, y, se, -1).into_iter().fold(f32::NEG_INFINITY, f32::max))
}

/// C2a. Opening: erode, then dilate.
pub fn open(img: &Image<f32>, se: &[(isize, isize)]) -> Image<f32> {
    dilate(&erode(img, se), se)
}

/// C2b. Closing: dilate, then erode.
pub fn close(img: &Image<f32>, se: &[(isize, isize)]) -> Image<f32> {
    erode(&dilate(img, se), se)
}

/// C2c. White top-hat: the image minus its opening (bright details smaller than the SE).
pub fn white_tophat(img: &Image<f32>, se: &[(isize, isize)]) -> Image<f32> {
    img.zip_map(&open(img, se), |i, o| i - o)
}

/// C2d. Black top-hat: the closing minus the image (dark details smaller than the SE).
pub fn black_tophat(img: &Image<f32>, se: &[(isize, isize)]) -> Image<f32> {
    close(img, se).zip_map(img, |c, i| c - i)
}

/// C3. The morphological gradient: dilation minus erosion (the range in the window).
pub fn gradient(img: &Image<f32>, se: &[(isize, isize)]) -> Image<f32> {
    dilate(img, se).zip_map(&erode(img, se), |d, e| d - e)
}

/// C4. The median filter: sort the values I(x + b) of the window and take the middle one
/// (for an even number of values, the upper of the two middle ones).
pub fn median(img: &Image<f32>, se: &[(isize, isize)]) -> Image<f32> {
    img.map_xy(|x, y, _| {
        let mut v = values_at(img, x, y, se, 1);
        v.sort_by(|a, b| a.total_cmp(b));
        v[v.len() / 2]
    })
}
